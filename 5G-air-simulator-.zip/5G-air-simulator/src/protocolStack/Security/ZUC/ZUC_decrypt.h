#ifndef _ZUC_decrypt_H_
#define _ZUC_decrypt_H_

#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <ostream>
#include <string>
#include <vector>
#include "../Diffie_Hellman/DH_DST.h"
#include "../../packet/Packet.h"
#include "ZUC.h"

class ZUC_decrypt{

    private:
    unsigned long long secretKeyDST; 
    const unsigned int cypertext;
    unsigned long long inLen;

    public:
    unsigned int decrypt(unsigned int ciphertext, unsigned char k[]);
    unsigned int main_ZUC_DST(unsigned int encryptPacket /*int packetSize*/);
};

#endif