#include "ZUC_decrypt.h"

/*
File:        ZUC_decrypt.cpp
Descrizione: La funzione "decrypt" decifra un intero cifrato utilizzando 
             l'algoritmo di cifratura ZUC. Viene utilizzato un vettore di 
             inizializzazione (iv) di 16 byte e una lunghezza di 2 per il keystream. 
             La chiave di cifratura (key) viene copiata da un array di char (k) 
             a un array di unsigned char (key). L'intero cifrato viene decifrato 
             tramite l'operazione XOR con il keystream generato da ZUC_GenKeyStream. 
             La funzione "main_ZUC_DST" utilizza l'oggetto DH_DST per generare 
             la chiave segreta ZUC (128 bit) e la copia in secretKeyDST. 
             L'intero cifrato compresso viene decifrato tramite la funzione 
             "decrypt" e il risultato viene restituito come intero decifrato. 
             La funzione stampa il testo decifrato sulla console.
*/

// Funzione per decifrare un intero cifrato utilizzando ZUC
unsigned int ZUC_decrypt::decrypt(unsigned int ciphertext, unsigned char k[]) {
    
    unsigned char iv[16] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    int KeystreamLen = 2; //the length of key stream
	unsigned int Keystream[2];
    unsigned char key[16]; 
    for (int i = 0; i < 16; i++) {
        key[i] = k[i];
    }
    // Decifra l'intero cifrato
    unsigned int decrypted = ciphertext ^ ZUC_GenKeyStream(key, iv, Keystream, KeystreamLen);
    return decrypted;

}

unsigned int ZUC_decrypt::main_ZUC_DST(unsigned int encryptPacket /*int packetSize*/) {
    
    DH_DST dd; // Creo un oggetto di DH_DST
    unsigned char secretKeyDST[16];

    //assegno a secretKeySRC il valore di ritorno di main_DH_SRC, cioè kb, chiave ZUC (128 bit)
    int intValue = dd.main_DH_DST();
    memcpy(secretKeyDST, &intValue, sizeof(int)); // Copia i byte dall'int all'array 
    
    unsigned int ciphertext = encryptPacket; // Pacchetto criptato compresso
    
    // Decifratura
    unsigned int decrypted = decrypt(ciphertext, secretKeyDST);

    std::cout << "Testo decifrato: " << decrypted << std::endl;
    
    return decrypted;
}