#ifndef _ZUC_encrypt_H_
#define _ZUC_encrypt_H_

#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <ostream>
#include <string>
#include <vector>
#include "../Diffie_Hellman/DH_SRC.h"
#include "../../packet/Packet.h"
#include "ZUC.h"

class ZUC_encrypt{
    
    private:
    const unsigned int secretKeySRC;   
    const unsigned int in;
    unsigned int inLen;

    public:
    unsigned int encrypt(unsigned int plaintext, unsigned char k[]);
    unsigned int main_ZUC_SRC(int packet /*int packetSize*/);

};

#endif