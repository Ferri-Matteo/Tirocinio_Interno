#ifndef _AES_DST_H_
#define _AES_DST_H_

/*
AES per il destintario:
This header file declares the AES_DST class, which provides a method for decrypting and decompressing data.

The AES_DST class has the following private member variables:

secretKeyDST: a constant array of unsigned char representing the secret key used for decryption.
in: a constant array of unsigned char representing the input data to be decrypted and decompressed.
inLen: an unsigned integer representing the length of the input data.
v: an array of unsigned char used as a temporary buffer.
The public method main_AES_DST takes two parameters:

compressedPacket: a pointer to an array of unsigned char representing the compressed and encrypted data.
packetSize: an integer representing the size of the compressedPacket.
The main_AES_DST function first creates an object of the DH_DST class to obtain the secret key using the Diffie-Hellman key exchange protocol. It then decompresses the input data using the uncompress function from the miniz.c library. Finally, it decrypts the decompressed data using the DecryptECB function from the AES.h library and returns a pointer to the decrypted data.

This header file should be included in any source file that needs to use the AES_DST class.*/

#include "AES.h"
#include "../Diffie_Hellman/DH_DST.h"
#include "../../packet/Packet.h"
#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include "miniz.c"
#include "tinfl.c"

class AES_DST{

    private:
    const unsigned char* secretKeyDST;
    const unsigned char* in;
    unsigned int inLen;
    unsigned char *v;

    public:
    unsigned char* main_AES_DST(unsigned char* compressedPacket /*pacchetto criptato compresso*/, int packetSize);
    

};

#endif
