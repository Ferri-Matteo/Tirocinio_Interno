#include "AES_DST.h"

/*
AES per il destinatario:

This is a C++ function named main_AES_DST in the AES_DST class, which takes two arguments: compressedPacket (a pointer to an array of unsigned chars containing encrypted and compressed data) and packetSize (an integer representing the size of the packet).
The function first creates an object (dd) of another class named DH_DST, then calls its method main_DH_DST() to generate a secret key (secretKeyDST).
Next, it assigns the input compressedPacket to inCompressoDST, and sets the length of the input packet to inLen.
Then, it decompresses the data using a function named uncompress(), which returns a pointer to an array of unsigned chars. This result is stored in decompressedData.
After that, the function decrypts the decompressed data using the ECB mode of decryption with the secret key generated earlier. The decrypted data is stored in decryptedData.
Finally, it deallocates the memory allocated for decompressedData and returns decryptedData.
*/

unsigned char* AES_DST::main_AES_DST(unsigned char* compressedPacket, int packetSize) {
    DH_DST dd; // Creo un oggetto di DH_DST   
    AES a(AESKeyLength::AES_128); //creo un oggetto di AES
    const unsigned char* decompressedData = nullptr;
    decompressedData = new unsigned char[100];

    int intValue = dd.main_DH_DST();
    const unsigned char* secretKeyDST = reinterpret_cast<const unsigned char*>(&intValue);

   /*int intValue = dd.main_DH_DST(); 
    unsigned char byteBuffer[sizeof(int)];
    // Copiare i byte dell'intero nell'array unsigned char
    memcpy(byteBuffer, &intValue, sizeof(int));
    // assegnare l'array unsigned char a secretKeyDST
    const unsigned char* secretKeyDST = byteBuffer;*/
   
    unsigned char* inCompressoDST = compressedPacket; // Pacchetto criptato compresso
    unsigned int inLen = packetSize; // Lunghezza pacchetto
    
    unsigned long tempDest_len = 100;
    unsigned char tempDest[tempDest_len];   
    unsigned long *pDest_len = &tempDest_len;
    
    int intResult = uncompress(tempDest, pDest_len, inCompressoDST, packetSize); // Decomprime i dati
    decompressedData = reinterpret_cast<const unsigned char*>(&intResult);
    /*unsigned char byteBuffer2[sizeof(int)];
    memcpy(byteBuffer2, &intResult, sizeof(int));
    // assegnare l'array unsigned char a compressedData
    decompressedData = byteBuffer2;*/

    unsigned char* decryptedData = a.DecryptECB(decompressedData, inLen, secretKeyDST); // Decripta il pacchetto
   
    delete[] decompressedData; // Elimina la memoria allocata per i dati decompressi
   
    return decryptedData;
}


 
