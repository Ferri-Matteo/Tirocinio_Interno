#ifndef _AES_SRC_H_
#define _AES_SRC_H_


/*
AES per il sorgente:
This is a C++ header file for a class named AES_SRC with a public method main_AES_SRC.
The class includes several header files including "AES.h", "DH_SRC.h", "Packet.h", and some standard C++ libraries.
The purpose of the AES_SRC class is to encrypt and compress data for the source side of a communication protocol.

The main_AES_SRC method takes two arguments: packet (a pointer to an object of type Packet containing the data to be encrypted and compressed) and packetSize (an integer representing the size of the packet).
The private section of the class contains four variables:

secretKeySRC: a constant array of unsigned chars representing the secret key for encryption
in: a constant array of unsigned chars representing the input data to be encrypted and compressed
inLen: an unsigned int representing the length of the input data
d: an array of unsigned chars representing the decompressed data
The main_AES_SRC method returns a pointer to an array of unsigned chars, which represents the encrypted and compressed data.

Note that there are also two typedef declarations for uint8 and uint16, as well as an undefined type uint. 
Additionally, the class includes two C source files ("miniz.c" and "tinfl.c") which contain functions for compression and decompression using the DEFLATE algorithm.*/

#include "AES.h"
#include "../Diffie_Hellman/DH_SRC.h"
#include "../../packet/Packet.h"
#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include "miniz.c"
#include "tinfl.c"

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint;

class AES_SRC{
    private:    
    const unsigned char *secretKeySRC;    
    unsigned char *d;    
    const unsigned int *in;
    unsigned int inLen;

    public:
    const unsigned char* main_AES_SRC(int packet, int packetSize);

};

#endif
