#include "AES_SRC.h"

/*
AES per il sorgente:

This is a C++ function named main_AES_SRC in the AES_SRC class, which takes two arguments: packet (a pointer to an object of type Packet containing the data to be encrypted and compressed) and packetSize (an integer representing the size of the packet).
The function first creates an object (ds) of another class named DH_SRC, then calls its method main_DH_SRC() to generate a secret key (secretKeySRC).
Next, it assigns the input packet to in, and sets the length of the input packet to inLen.
Then, it encrypts the input data using the ECB mode of encryption with the secret key generated earlier. The encrypted data is stored in encryptedData.
After that, the function compresses the encrypted data using a function named compress(), which returns a pointer to an array of unsigned chars. This result is stored in compressedData.
Finally, it deallocates the memory allocated for encryptedData and returns compressedData.
*/

const unsigned char* AES_SRC::main_AES_SRC(int packet, int packetSize){
    
    DH_SRC ds; //creo un oggetto di DH_SRC
    AES a(AESKeyLength::AES_128); //creo un oggetto di AES
    
    const unsigned char* compressedData = nullptr;
    compressedData = new unsigned char[100];
   
    int intValue = ds.main_DH_SRC(); // Assegno a intValue il valore di ritorno di main_DH_SRC, cioè ka
    // Creare un array di unsigned char per memorizzare i byte dell'intero
    unsigned char byteBuffer[sizeof(int)];
    // Copiare i byte dell'intero nell'array unsigned char
    memcpy(byteBuffer, &intValue, sizeof(int));
    // assegnare l'array unsigned char a secretKeyDST
    const unsigned char* secretKeySRC = byteBuffer;
    
    int pacchetto = packet; /*pacchetto non criptato*/;
    // Creare un array di unsigned char per memorizzare i byte dell'intero
    unsigned char byteBuffer3[sizeof(int)];
    // Copiare i byte dell'intero nell'array unsigned char
    memcpy(byteBuffer3, &pacchetto, sizeof(int));
    // assegnare l'array unsigned char a in
    const unsigned char* in = byteBuffer3;
    
    unsigned int inLen = packetSize; /*lunghezza pacchetto*/

    unsigned char *encryptedData = a.EncryptECB(in, inLen, secretKeySRC); //cripta con AES il pacchetto

    unsigned char tempDest[100];
    unsigned long tempDest_len = 100;
    unsigned long *pDest_len = &tempDest_len;
    
    int intResult = compress(tempDest, pDest_len, encryptedData, packetSize); // comprime i dati criptati
    unsigned char byteBuffer2[sizeof(int)];
    memcpy(byteBuffer2, &intResult, sizeof(int));
    // assegnare l'array unsigned char a compressedData
    compressedData = byteBuffer2;
    
    delete[] encryptedData; // Elimina la memoria allocata per i dati criptati
    
    return compressedData;
}




