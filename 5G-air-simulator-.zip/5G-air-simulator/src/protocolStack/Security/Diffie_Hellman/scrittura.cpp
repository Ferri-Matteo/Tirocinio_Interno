
/*
This code defines the implementation file for a class named scrittura. The class includes a default constructor scrittura() and a public member function main_Scrittura().

/*
The purpose of this class is to connect to a server socket and send data. It uses the iostream, sys/socket.h, arpa/inet.h, unistd.h, and string libraries.
The main_Scrittura() function creates a client socket, sets the IP address and port number of the server, connects to the server, converts a long long integer into a string, sends the string as a message to the server, and closes the socket.
The function returns an integer value of 0 if the message was successfully sent, or 1 if there was an error during any of these steps. If an error occurs, an appropriate error message is displayed
*/

#include "scrittura.h"

scrittura::scrittura(){}

int scrittura::main_Scrittura(long long int G) {
    // Creazione della socket
    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1) {
        std::cerr << "Errore durante la creazione della socket" << std::endl;
        return 1;
    }

    // Configurazione dell'indirizzo del server
    std::string serverIP = "127.0.0.1";
    int serverPort = 8080;

    sockaddr_in serverAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(serverPort);
    if (inet_pton(AF_INET, serverIP.c_str(), &(serverAddress.sin_addr)) <= 0) {
        std::cerr << "Indirizzo server non valido" << std::endl;
        return 1;
    }

    // Connessione al server
    if (connect(clientSocket, reinterpret_cast<sockaddr*>(&serverAddress), sizeof(serverAddress)) == -1) {
        std::cerr << "Connessione al server non riuscita" << std::endl;
        return 1;
    }

    // Messaggio da inviare al server
    std::string message = std::to_string(G);

    // Invio del messaggio al server
    ssize_t bytesSent = send(clientSocket, message.c_str(), message.size(), 0);
    if (bytesSent == -1) {
        std::cerr << "Errore durante l'invio del messaggio" << std::endl;
        return 1;
    }

    std::cout << "Messaggio inviato al server" << std::endl;

    // Ricezione della risposta dal server
    char buffer[1024];
    ssize_t bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);
    if (bytesRead == -1) {
        std::cerr << "Errore durante la ricezione della risposta" << std::endl;
    } else {
        std::string response(buffer, bytesRead);
        std::cout << "Risposta ricevuta dal server: " << response << std::endl;
    }

    // Chiusura della socket
    close(clientSocket);

    return 0;
}

