
#include "Ruolo.h"
#include "DH_SRC.h"

/*
Diffie-Hellman per il sorgente:

This code defines the implementation file for a class named DH_SRC. The class contains a constructor DH_SRC(), and four member functions: getPublicKeySRC(), contact(), rcv(), and powerSRC().
The getPublicKeySRC() function generates a random long long integer between 2 and 256. The contact() function writes the value of P on the socket using the scrittura class, while the rcv() function reads from the socket using the lettura class. The powerSRC() function returns the result of computing G^a mod P.
The main_DH_SRC() function is the main algorithm that implements the Diffie-Hellman key exchange protocol. It generates a random private key a, sends the public key P to the destination (DST), receives the public key G from DST, computes the shared secret key ka, and returns it.
The function also uses error checking by returning values of 1 in case there is an error during the transmission or reception of values on the socket. The header files Ruolo.h and DH_SRC.h are included in this implementation file. The using namespace std; statement is also used in this file.
*/

using namespace std;

DH_SRC::DH_SRC(){}

long long int DH_SRC::getPublicKeySRC (){
    srand(time(NULL)); //inizializza i valori
    long long int P = rand()%256+2;
    return P;
}

//invia long long int P al destinatario
int DH_SRC::contact(long long int P) {
   // scrivi chiave pubblica su socket
   scrittura s;
   int n = s.main_Scrittura(P); // remove unnecessary typecast
   return n;
}

//riceve long long int G dal destinatario
int DH_SRC::rcv(){
   long long int G;
   lettura l;

   // leggi chiave pubblica da socket 
   std::string strValue = l.mainLettura();

    try {
        // Converte la stringa in un long long int
        G = std::stoll(strValue);
    } catch (const std::invalid_argument& e) {
        // se la conversione non riesce stampa un messaggio di errore
        std::cerr << "Errore di conversione: " << e.what() << std::endl;
        G = 1; //P = 1 in caso di errore
    } catch (const std::out_of_range& e) {
        //se il valore è fuori dal range di un long long int stampa un messaggio di errore
        std::cerr << "Valore fuori dal range: " << e.what() << std::endl;
        G = 1; // P = 1 in caso di errore
    }

   if (G==1){
    std::cerr << "Errore durante la ricezione" << std::endl;
   }
   return G;
}

// Power function to return value of G ^ a mod P
long long int DH_SRC::powerSRC(long long int G, long long int a, long long int P){
    if (a == 1)
        return G;
    else
        return ((long long int)pow(G, a)) % P; 
}

int DH_SRC::main_DH_SRC(){
    int setRuolo = 0; // initialize setRuolo to 0
    long long int a;
    long long int G;
    int x;
    int y;
    int ka;
    
    long long int P = getPublicKeySRC();
    cout << "il valore di P è : "<< P << endl;
    
    int contatto = contact(P);
    if (contatto == 1){ 
        std::cerr << "Errore durante l'invio" << std::endl; 
    } else {
        cout << "Ho contattato il server correttamente" << endl;
    }

    while (true){
        int ricevuta_G = 1;
        //aspetta di ricevere dal DST la chiave G
        if ((G = rcv()) != NULL){ 
            ricevuta_G = 0;
            std::cerr << "Ho ricevuto la chiave G" << std::endl; 
            break;
        }
    }

    // SRC will choose the private key a
    srand(time(NULL)); //inizializza i valori
    a = rand()%256+2; // a is the chosen private key creando un numero casuale da 2 a 256
    cout << "La chiave privata di SRC è : " << a << endl;

    x = powerSRC(G, a, P); // gets the generated key
    contact(x);
    
    while (true){
        int ricevuta_y = 1;
        //aspetta di ricevere dal DST la chiave y
        if ((y = rcv()) != NULL){ 
            ricevuta_y = 0;
            std::cerr << "Ho ricevuto la chiave y" << std::endl; 
            break;
        }
    }

    ka = powerSRC(y, a, P);
    cout << "La chiave condivisa per SRC e DST è : " << ka << endl;

    return ka;

}