/* This program calculates the Key for one person
using the Diffie-Hellman Key exchange algorithm using C++ */

#include "Ruolo.h"
using namespace std;

int Ruolo::setRuolo(int s){
	/* 
    ini = 0 se comincio la comunicazione
    ini non definito
    ini = 1 se ricevo 
    */
	int ini = s; 
    return ini;
}


