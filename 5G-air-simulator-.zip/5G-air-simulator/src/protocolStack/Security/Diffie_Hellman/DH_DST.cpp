/*This function implements the main logic of the Diffie-Hellman key exchange protocol from the 
perspective of the destination device. It first waits to receive the public key P from the 
source device. Then it generates its own public key G and sends it to the source device. 
Next, it chooses a random private key*/

#include "DH_DST.h"

using namespace std;

/*Constructor
The constructor is empty and does not perform any operations.*/
DH_DST::DH_DST(){}

/*getPublicKeyDST
This function generates a random number between 2 and 257 and returns it as the public key G*/
long long int DH_DST::getPublicKeyDST (){
    srand(time(NULL)); //inizializza i valori
    long long int G = rand()%256+2;
    return G;
}

/*contact
This function sends the public key G to the source device over a socket. 
It uses the scrittura class to write to the socket and returns the number of bytes written.
Invia long long int G al sorgente*/
int DH_DST::contact(long long int G) {
   // scrivi chiave pubblica su socket
   scrittura s;
   int n = s.main_Scrittura(G);
   return n;
}



/*rcv
This function receives the public key P from the source device over a socket. 
It uses the lettura class to read from the socket. If an error occurs during the reception, 
it prints an error message to standard error output and returns 1. Otherwise, it returns P.
Riceve long long int P dal sorgente*/

int DH_DST::rcv(){
    long long int P;
   // leggi chiave pubblica da socket    
   lettura l;
    
    // l.mainLettura() restituisce una stringa
    std::string strValue = l.mainLettura();

    try {
        // Converte la stringa in un long long int
        P = std::stoll(strValue);
    } catch (const std::invalid_argument& e) {
        // se la conversione non riesce stampa un messaggio di errore
        std::cerr << "Errore di conversione: " << e.what() << std::endl;
        P = 1; //P = 1 in caso di errore
    } catch (const std::out_of_range& e) {
        //se il valore è fuori dal range di un long long int stampa un messaggio di errore
        std::cerr << "Valore fuori dal range: " << e.what() << std::endl;
        P = 1; // P = 1 in caso di errore
    }

   if (P==1){
    std::cerr << "Errore durante la ricezione" << std::endl;
   }
   return P;
} 

/*powerDST
This function calculates and returns the value of G raised to the power of a modulo P, 
using the pow and fmod functions. Power function to return value of G ^ a mod P*/

long long int DH_DST::powerDST(long long int G, long long int a, long long int P){
    if (a == 1)
        return G;
    else
        return fmod(pow(G, a), P); // remove unnecessary typecast
}


//main_DH_DST
int DH_DST::main_DH_DST(){
    long long int b;
    long long int P;
    int x = 0; // initialize x to 0
    int y;

    while (true){
        int ricevuta_P = 1;
        //aspetta di ricevere dal SRC la chiave P
        if ((P = rcv()) != NULL){ 
            ricevuta_P = 0;
            int setRuolo (1);
            std::cerr << "Ho ricevuto la chiave P" << std::endl; 
            break;
        }
    }

    long long int G = getPublicKeyDST();
    cout << "il valore di G è : "<< G << endl; // use G instead of P
    
    int contatto = contact(G);
    if (contatto == 1){ // use equality operator instead of assignment operator
        cout << "Errore durante l'invio" << endl;
    } else {
        cout << "Ho contattato il server correttamente" << endl;
    }

    // DST will choose the private key b
    srand(time(NULL)); //inizializza i valori
    b = rand()%256+2; // a is the chosen private key creando un numero casuale da 2 a 256
    cout << "La chiave privata di DST è : " << b << endl;

    y = powerDST(G, b, P); // gets the generated key
    contact(y);
    
    long long int kb = 0; // declare kb before using it
    while (true){
        int ricevuta_x = 1;
        //aspetta di ricevere dal DST la chiave x
        if ((x = rcv()) != NULL){ // replace null with NULL
            ricevuta_x = 0;
            std::cerr << "Ho ricevuto la chiave x" << std::endl; 
            break;
        }
    }

    kb = powerDST(x, b, P);
    cout << "La chiave condivisa per SRC e DST è : " << kb << endl;
    return kb;
}


