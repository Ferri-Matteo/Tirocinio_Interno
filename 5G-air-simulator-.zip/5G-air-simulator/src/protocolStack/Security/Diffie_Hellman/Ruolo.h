
/* 
This program calculates the Key for one persons
using the Diffie-Hellman Key exchange algorithm using C++ 

This code defines the header file for a class named Ruolo. The header file includes the cmath, iostream, and sys/socket.h libraries.
The purpose of this class is to set the role of an instance of Ruolo as either 0 or 1. The class includes a public member function setRuolo() that takes an integer value as a parameter.
If the parameter is 0, setRuolo() sets the ini variable to 2. If the parameter is 1, setRuolo() sets the ini variable to 3. The ini variable is a public member of the class, initialized to 2.
This header file is protected from multiple inclusion by using an #ifndef preprocessor directive.
*/

#ifndef _Ruolo_H_
#define _Ruolo_H_

#include <cmath>
#include <iostream>
#include <sys/socket.h>

class Ruolo 
{
    public:
    int ini = 2;
    int setRuolo (int s);
    
};

#endif

