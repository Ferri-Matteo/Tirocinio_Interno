
/*This code defines the header file for a class named lettura. The class includes a default constructor lettura() and a public member function mainLettura().
The purpose of this class is to read data from a socket. It uses the sys/socket.h, arpa/inet.h, unistd.h, and string libraries.
The mainLettura() function returns an integer value, which represents the data read from the socket.*/

#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string>

class lettura{

    public: 
    lettura();
    std::string mainLettura();
};
