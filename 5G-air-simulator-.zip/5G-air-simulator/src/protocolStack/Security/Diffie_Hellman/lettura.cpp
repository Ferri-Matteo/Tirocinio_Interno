
/*
This code defines the implementation file for a class named lettura. The class includes a default constructor lettura() and a public member function mainLettura().
The purpose of this class is to listen on a socket for incoming connections, receive a message from a client, send a response, and close the connection. It uses the iostream, sys/socket.h, arpa/inet.h, unistd.h, and string libraries.
The mainLettura() function creates a server socket, binds it to an IP address and port number, listens for incoming connections, accepts a connection from a client, receives a message from the client, sends a response to the client, and closes the sockets.
The function returns the received message as a string. If an error occurs during any of these steps, the function returns an integer value of 1 and displays an appropriate error message
*/

#include "lettura.h"

lettura::lettura(){}

std::string lettura::mainLettura() {
    // Creazione della socket
    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        std::cerr << "Errore durante la creazione della socket" << std::endl;
    }

    // Configurazione dell'indirizzo del server
    std::string serverIP = "127.0.0.1";
    int serverPort = 8080;

    sockaddr_in serverAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(serverPort);

    // Bind della socket all'indirizzo del server
    if (bind(serverSocket, reinterpret_cast<sockaddr*>(&serverAddress), sizeof(serverAddress)) == -1) {
        std::cerr << "Errore durante il binding della socket" << std::endl;
    }

    // In ascolto delle connessioni
    if (listen(serverSocket, 1) == -1) {
        std::cerr << "Errore durante l'ascolto delle connessioni" << std::endl;
    }

    std::cout << "Server in ascolto su " << serverIP << ":" << serverPort << std::endl;

    // Accettazione di una connessione dal client
    sockaddr_in clientAddress{};
    socklen_t clientAddressLength = sizeof(clientAddress);
    int clientSocket = accept(serverSocket, reinterpret_cast<sockaddr*>(&clientAddress), &clientAddressLength);
    if (clientSocket == -1) {
        std::cerr << "Errore durante l'accettazione della connessione" << std::endl;
    }

    // Ricezione del messaggio dal client
    char buffer[1024];
    ssize_t bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);
    if (bytesRead == -1) {
        std::cerr << "Errore durante la ricezione del messaggio" << std::endl;
    }

    std::string message(buffer, bytesRead);
    std::cout << "Messaggio ricevuto dal client: " << message << std::endl;

    // Preparazione della risposta da inviare al client
    std::string response = "Ciao, client! Ho ricevuto il tuo messaggio.";

    // Invio della risposta al client
    ssize_t bytesSent = send(clientSocket, response.c_str(), response.size(), 0);
    if (bytesSent == -1) {
        std::cerr << "Errore durante l'invio della risposta" << std::endl;
    }

    std::cout << "Risposta inviata al client" << std::endl;

    // Chiusura della socket del client
    close(clientSocket);

    // Chiusura della socket del server
    close(serverSocket);

    return message;
}
