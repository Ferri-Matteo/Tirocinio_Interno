#ifndef _DH_SRC_H_
#define _DH_SRC_H_

/*
Diffie_hellman per il sorgente:


This code defines the header file for a class named DH_SRC. The class contains a private data member ka of type integer, and three private member functions: getPublicKeySRC(), contact(), and rcv().
The class also includes a public constructor DH_SRC(), and a public member function main_DH_SRC(). Within the header file, the cmath, iostream, and stdio.h libraries are included. Additionally, the header files scrittura.h and lettura.h are included.
The function powerSRC() is also defined within the class; it takes in three long long integers as parameters, and returns another long long integer.
This header file is protected from multiple inclusion by using an #ifndef preprocessor directive. */

#include <string>
#include <cmath>
#include <iostream>
#include <stdio.h>
#include "scrittura.h"
#include "lettura.h"

class DH_SRC{
    private:
    int ka;

    public:
    DH_SRC();
    int main_DH_SRC();
    
    private:
    long long int getPublicKeySRC ();
    
    int contact(long long int P);
    
    int rcv();
    
    long long int powerSRC(long long int G, long long int a,
					long long int P);
    
    

};

#endif
