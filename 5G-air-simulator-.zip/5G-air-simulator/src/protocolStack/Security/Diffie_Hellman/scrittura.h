
/*
This code defines the header file for a class named scrittura. The class includes a default constructor scrittura() and a public member function main_Scrittura().
The purpose of this class is to write data to a socket. It uses the sys/socket.h, arpa/inet.h, unistd.h, and string libraries.
The main_Scrittura() function takes a long long integer value as a parameter, which represents the data to be written to the socket. The function returns an integer value, which represents the success of writing the data to the socket.
*/

#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string>

class scrittura{

    public: 
    scrittura();
    int main_Scrittura(long long int G);
};