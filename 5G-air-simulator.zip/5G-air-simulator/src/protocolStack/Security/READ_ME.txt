Per compilare ed eseguire i file bisogna recarsi nel path 5G-air-simulator\src\protocolStack\Security di 5G-air-simulator.
Dopodichè bisogna seguire le istruzioni sotto riportate:

Per ZUC:
    Compilazione:
            - g++ -o ZUCSRC ZUC/mainZUCSRC.cpp ZUC/ZUC_encrypt.cpp ZUC/ZUC.cpp Diffie_Hellman/DH_dst.cpp 
            - g++ -o ZUCDST ZUC/mainZUCDST.cpp ZUC/ZUC_decrypt.cpp ZUC/ZUC.cpp Diffie_Hellman/DH_src.cpp
    Esecuzione:
            - ./ZUCSRC
            - ./ZUCDST

Per AES:
    Compilazione:
            - g++ -o AESSRC AES/mainAESSRC.cpp AES/AES.cpp AES/AES_SRC.cpp Diffie_Hellman/DH_dst.cpp 
            - g++ -o AESDST AES/mainAESDST.cpp AES/AES.cpp AES/AES_DST.cpp Diffie_Hellman/DH_src.cpp 
    Esecuzione:
            - ./AESSRC
            - ./AESDST

Per Diffie_Hellman:
    Compilazione: 
            - g++ -o DHSRC Diffie_Hellman/DH_src.cpp Diffie_Hellman/mainDHSRC.cpp
            - g++ -o DHDST Diffie_Hellman/DH_dst.cpp Diffie_Hellman/mainDHDST.cpp
    Esecuzione:
            - ./DHDST
            - ./DHSRC