/*
Nome del file:  "ZUC_decrypt.h"

Descrizione:    E' il codice con l'instestazione di ZUC_decrypt.cpp.
                Viene definita una classe chiamata ZUC_decrypt, che ha un costruttore vuoto 
                due metodi chiamati main_ZUC_DST e decrypt.
*/

#ifndef _ZUC_decrypt_H_
#define _ZUC_decrypt_H_

#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <ostream>
#include <string>
#include <vector>
#include "../Diffie_Hellman/DH_src.h"
#include "../../packet/Packet.h"
#include "ZUC.h"

class ZUC_decrypt{

    public:
    ZUC_decrypt(){};
    unsigned int decrypt(unsigned int ciphertext, unsigned char k[]);
    unsigned int main_ZUC_DST(unsigned int encryptPacket /*int packetSize*/);
};

#endif