#include "ZUC_encrypt.h"

/*
Nome del file:    "ZUC_encrypt.cpp"

Descrizione:      contiene due funzioni: "encrypt" e "main_ZUC_SRC". 
                  La funzione "encrypt" prende un intero "plaintext" e una chiave "k" come input e 
                  restituisce l'intero cifrato utilizzando l'algoritmo di cifratura ZUC. 
                  La funzione "main_ZUC_SRC" crea un oggetto di tipo DH_SRC chiamato "ds" e 
                  genera una chiave segreta utilizzando l'algoritmo DH_SRC. 
                  Viene quindi chiamata la funzione "encrypt" per cifrare un pacchetto 
                  utilizzando la chiave segreta generata.
*/

ZUC_encrypt::ZUC_encrypt(){};

// Funzione per cifrare un intero utilizzando ZUC
unsigned int ZUC_encrypt::encrypt(unsigned int plaintext, unsigned char k[]) {

    unsigned char key[16]; 
    for (int i = 0; i < 16; i++) {
        key[i] = k[i];
    }
    // Cifra l'intero
    unsigned int ciphertext = plaintext ^ main_ZUC(key);
    return ciphertext;

}

unsigned int ZUC_encrypt::main_ZUC_SRC(int packet /*int packetSize*/){

    DH_dst ds; //creo un oggetto di DH_SRC
    unsigned char secretKeySRC[16];

    //assegno a secretKeySRC il valore di ritorno di main_DH_SRC, cioè ka, Chiave ZUC (128 bit)
    int intValue = ds.main_DH_DST();
    memcpy(secretKeySRC, &intValue, sizeof(int)); // Copia i byte dall'int all'array 
      
    unsigned int in = static_cast<unsigned int>(packet); /*pacchetto non criptato*/;

    // Cifratura
    unsigned int ciphertext = encrypt(in, secretKeySRC); //cifra con ZUC il pacchetto

    std::cout << "Testo cifrato: " << ciphertext << std::endl;
    
    return ciphertext;
}
