/*
Nome del file:  "mainZUCSRC.cpp"

Descrizione:    E' il main dell'applicazione ZUC per il sorgente
*/


#include "ZUC_encrypt.h"

int main() {
    int p = 01000010010;
    ZUC_encrypt ze;
    unsigned int en = ze.main_ZUC_SRC(p) ;
    return 0;
    
}
