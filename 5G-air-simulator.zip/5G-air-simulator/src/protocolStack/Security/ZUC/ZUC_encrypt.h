/*
Nome del file:  "ZUC_encrypt.h"

Descrizione:    E' il codice con l'instestazione di ZUC_encrypt.cpp.
                Viene definita una classe chiamata ZUC_encrypt, che ha un costruttore vuoto 
                due metodi chiamati main_ZUC_SRC e encrypt.
*/

#ifndef _ZUC_encrypt_H_
#define _ZUC_encrypt_H_

#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <ostream>
#include <string>
#include <vector>
#include "../Diffie_Hellman/DH_dst.h"
#include "../../packet/Packet.h"
#include "ZUC.h"

class ZUC_encrypt{

    public:
    ZUC_encrypt();
    unsigned int encrypt(unsigned int plaintext, unsigned char k[]);
    unsigned int main_ZUC_SRC(int packet /*int packetSize*/);

};

#endif