/*
Nome del file:  "mainZUCDST.cpp"

Descrizione:    E' il main dell'applicazione ZUC per il destinatario
*/

#include "ZUC_decrypt.h"

int main() {
    
    unsigned int packetc = 01000010010;
    ZUC_decrypt zd;
    unsigned int s= zd.main_ZUC_DST(packetc) ;
    return 0;
    
}