/*
Nome del file:  "ZUC.h"

Descizione:     Il codice definisce le dichiarazioni delle funzioni per l'algoritmo ZUC. 
                Le funzioni incluse nel codice sono: 
                - GenerateKeyStream: questa funzione genera il flusso di chiavi utilizzando 
                il segreto chiave e la lunghezza specificata. 
                - Initialization: questa funzione inizializza l'algoritmo ZUC utilizzando 
                la chiave segreta e il vettore di inizializzazione specificati. 
                - main_ZUC: questa è la funzione principale dell'algoritmo ZUC che prende la chiave 
                segreta come parametro e restituisce il risultato dell'algoritmo ZUC.
*/

#ifndef ZUC_H
#define ZUC_H

void GenerateKeyStream(unsigned int *pKeyStream, unsigned int KeyStreamLen);
void Initialization(unsigned char *k, unsigned char *iv);
unsigned int main_ZUC(unsigned char secretKey[]);

#endif
