/*
Nome del file:  "DH.h"

Descrizione:   La classe DH è una classe che implementa un protocollo di 
               scambio di chiavi Diffie-Hellman. Il protocollo permette a due entità 
               di generare una chiave condivisa senza dover scambiare la chiave stessa.   
               La classe ha diversi metodi per configurare le socket del server e del client, 
               stabilire una connessione tra il server e il client, inviare e ricevere dati 
               di tipo long long int tramite la socket, generare una chiave pubblica e calcolare 
               una potenza modulo un numero primo. 
*/

#include <iostream>
#include <string>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <cmath>
#include<stdio.h>

class DH {
public:

int serverSocket;
int clientSocket;

void setUpServerSocket(int port) {
    // Creazione della socket server
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        std::cerr << "Errore durante la creazione della socket server" << std::endl;
        exit(1);
    }

    int reuse = 1;
    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
   
    // Configurazione dell'indirizzo del server
    sockaddr_in serverAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(port); // Sostituisci con la porta desiderata

    // Bind della socket server all'indirizzo del server
    if (bind(serverSocket, reinterpret_cast<sockaddr*>(&serverAddress), sizeof(serverAddress)) == -1) {
        std::cerr << "Errore durante il binding della socket server" << std::endl;
        exit(1);
    }

    // In ascolto delle connessioni
    if (listen(serverSocket, 1) == -1) {
        std::cerr << "Errore durante l'ascolto delle connessioni" << std::endl;
        exit(1);
    }

    std::cout << "Server in ascolto sulla porta: " << port << std::endl;
}

void waitForConnectionFromClient() {
    sockaddr_in clientAddress{};
    socklen_t clientAddressLength = sizeof(clientAddress);
    clientSocket = accept(serverSocket, reinterpret_cast<sockaddr*>(&clientAddress), &clientAddressLength);
    if (clientSocket == -1) {
        std::cerr << "Errore durante l'accettazione della connessione da SRC" << std::endl;
        exit(1);
    }

    std::cout << "Connessione da SRC stabilita" << std::endl;
}
    
void setUpClientSocket(int port) {
    // Creazione della socket client
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1) {
        std::cerr << "Errore durante la creazione della socket client" << std::endl;
        exit(1);
    }
 
    int reuse = 1;
    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));

    // Configurazione dell'indirizzo del server a cui connettersi
    sockaddr_in serverAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(port); // Sostituisci con la porta desiderata
    if (inet_pton(AF_INET, "127.0.0.1", &(serverAddress.sin_addr)) <= 0) {
        std::cerr << "Indirizzo server non valido" << std::endl;
        exit(1);
    }

    // Connessione al server
    if (connect(clientSocket, reinterpret_cast<sockaddr*>(&serverAddress), sizeof(serverAddress)) == -1) {
        std::cerr << "Connessione al server non riuscita" << std::endl;
        exit(1);
    }

    std::cout << "Connesso al server sulla porta: " << port << std::endl;
}

int sendLongLong(long long int dataToSend) {
    ssize_t bytesSent = send(clientSocket, &dataToSend, sizeof(dataToSend), 0);
    if (bytesSent == -1) {
        std::cerr << "Errore durante l'invio di long long int" << std::endl;
    }
    return 0;
}

long long int receiveLongLong() {
    long long int receivedData;
    ssize_t bytesRead = recv(clientSocket, &receivedData, sizeof(receivedData), 0);
    if (bytesRead == -1) {
        std::cerr << "Errore durante la ricezione di long long int" << std::endl;
        return -1; // Gestisci l'errore come preferisci
    }
    return receivedData;
}

    //metodo per generare una chiave
    long long int getPublicKey (){
    static bool srandCalled = false; // Utilizziamo una variabile statica per chiamare srand solo una volta

    if (!srandCalled) {
        srand(time(NULL)); // Inizializza il generatore di numeri casuali solo la prima volta
        srandCalled = true;
    }

    long long int A = rand() % 256 + 2;
    return A;
    }

    // Power function to return value of G ^ a mod P
    long long int power(long long int G, long long int a, long long int P){
    if (a == 0)
        return 1;

    long long int result = 1;
    G = G % P;

    while (a > 0) {
        if (a % 2 == 1)
            result = (result * G) % P;

        a = a >> 1; // Dividi a per 2
        G = (G * G) % P;
    }

    return result;
}
 
    void closeSockets() {
        if (serverSocket != -1) {
            close(serverSocket);
            serverSocket = -1; // Imposta i descrittori delle socket a -1 dopo la chiusura
        }
        if (clientSocket != -1) {
            close(clientSocket);
            clientSocket = -1; // Imposta i descrittori delle socket a -1 dopo la chiusura
        }
    }
    
    void closeSocket() {
        if (serverSocket != -1) {
            close(serverSocket);
            serverSocket = -1; // Imposta i descrittori delle socket a -1 dopo la chiusura
        }
    }
};
