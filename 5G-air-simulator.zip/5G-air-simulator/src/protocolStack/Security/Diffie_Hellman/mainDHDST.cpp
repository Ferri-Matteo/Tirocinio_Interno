/*
Nome del file:  "mainDHDST.cpp"

Descrizione:    E' il main dell'applicazione Diffie_Hellman per il destinatario
*/

#include "DH_dst.h"

int main(){

    DH_dst dd;
    std::cerr << "inizia il main" << std::endl;
    long long int risultato = dd.main_DH_DST();
    std::cerr << "finito il main, risultato: "  << risultato << std::endl;  
    return 0;
}