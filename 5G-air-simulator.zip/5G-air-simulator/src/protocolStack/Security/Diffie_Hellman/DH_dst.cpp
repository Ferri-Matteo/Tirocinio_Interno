/*
Nome del file:  "DH_dst.cpp"

Descrizione:    Il codice sopra implementa la funzione principale per la classe DH_dst. 
                Utilizza il protocollo di scambio chiavi Diffie-Hellman per stabilire una 
                chiave segreta condivisa tra una sorgente (SRC) e una destinazione (DST).
*/

#include "DH_dst.h"

long long int DH_dst::main_DH_DST() {
    DH dst; // Crea un oggetto DH per il destinatario
    long long int G = dst.getPublicKey();
    std::cerr << "il valore di G è: " << G << std::endl;

    std::cerr << "--------------------------" << std::endl;
    
    // Configurazione della socket server
    int port = 8080;
    dst.setUpServerSocket(port);

    // Aspetta una connessione da SRC
    dst.waitForConnectionFromClient();

    // Ricevi P dal sorgente
    long long int P = dst.receiveLongLong();
    if (P == -1) {
        std::cerr << "Errore durante la ricezione della chiave P." << std::endl;
        dst.closeSockets();
        return 1;
    }else{
        std::cerr << "ricevuto P: " << P << std::endl;
    }

    // Chiudi la socket server quando hai finito con la modalità server
    dst.closeSockets();

    std::cerr << "--------------------------" << std::endl;

    sleep(1);

    // Configurazione della socket server
    int port2 = 8081;
    dst.setUpClientSocket(port2);

    // Invia G al sorgente
    int c = dst.sendLongLong(G);
    if (c==-1) {
        std::cerr << "Errore durante l'invio della chiave G." << std::endl;
        dst.closeSockets();
        return 1;
    }else{
        std::cerr << "inviato bene G" << std::endl;
    }

    dst.closeSockets();
    
    std::cerr << "--------------------------" << std::endl;

    // Genera b (la chiave privata)
    long long int b = dst.getPublicKey();
    std::cerr << "la chiave b: " << b << std::endl;

    std::cerr << "--------------------------" << std::endl; 
    
    // Calcola la chiave condivisa
    long long int y = dst.power(G, b, P);
    std::cerr << "la chiave y: " << y << std::endl;

    std::cerr << "--------------------------" << std::endl; 

    sleep(1);

    // Configurazione della socket client
    int port3 = 9096;
    dst.setUpClientSocket(port3);

    // Invia y al sorgente
    int d = dst.sendLongLong(y);
    if (d==-1) {
        std::cerr << "Errore durante l'invio della chiave y" << std::endl;
        dst.closeSockets();
        return 1;
    }else{
        std::cerr << "inviato bene y" << std::endl;
    }
    
    dst.closeSockets();

    std::cerr << "--------------------------" << std::endl;    
    
    // Configurazione della socket server
    int port4 = 7076;
    dst.setUpServerSocket(port4);

    // Aspetta una connessione da SRC
    dst.waitForConnectionFromClient();

    // Ricevi x dal sorgente
    long long int x = dst.receiveLongLong();
    if (x == -1) {
        std::cerr << "Errore durante la ricezione della chiave x." << std::endl;
        dst.closeSockets();
        return 1;
    }else{
        std::cerr << "ricevuto x: " << x << std::endl;
    }
    
    std::cerr << "--------------------------" << std::endl;

    //chiudi le socket
    dst.closeSockets();

    std::cerr << "--------------------------" << std::endl;

    //calcola kb, la chiave condivisa tra SRC e DST
    long long int kb = dst.power(x, b, P);
    cout << "La chiave condivisa per SRC e DST è : " << kb << endl;

    return kb;
}
