/*
Nome del file:  "DH_src.cpp"

Descrizione:   Questa funzione implementa il protocollo Diffie-Hellman per la generazione di una chiave 
               condivisa tra due parti, in questo caso SRC e DST. per farlo:
                - Viene inizializzato un oggetto Diffie-Hellman e generata la chiave privata e pubblica. 
                - Viene configurata una socket client e inviata la chiave pubblica P al destinatario. 
                - Viene configurata una socket server e attesa la connessione da parte del destinatario. 
                - Viene ricevuta la chiave pubblica G dal destinatario. 
                - Viene calcolata la chiave a e la chiave condivisa x utilizzando la funzione power. 
                - Viene configurata una nuova socket server e attesa la connessione dal destinatario. 
                - Viene ricevuta la chiave y dal destinatario. 
                - Viene inviata la chiave x al destinatario utilizzando una socket client. 
                - Viene calcolata la chiave condivisa ka tra SRC e DST utilizzando la funzione power. 
                - La funzione restituisce la chiave condivisa ka.
*/


#include "DH_src.h"

long long int DH_src::main_DH_src() {
    // Inizializza l'oggetto Diffie-Hellman e genera la chiave privata e pubblica
    DH dh_src;
    long long int P = dh_src.getPublicKey();
    std::cerr << "il valore di P è: " << P << std::endl;

    std::cerr << "--------------------------" << std::endl;

    // Configurazione della socket client

    sleep(1);

    int port = 8080;
    dh_src.setUpClientSocket(port);

    // Scambio delle chiavi pubbliche
    int c = dh_src.sendLongLong(P);
    if (c==-1) {
        std::cerr << "Errore durante l'invio della chiave pubblica al destinatario." << std::endl;
        dh_src.closeSockets();
        return 1;
    }else{
        std::cerr << "inviato bene P" << std::endl;
    }

    dh_src.closeSockets();
    
    std::cerr << "--------------------------" << std::endl;

    // Configurazione della socket server
    int port2 = 8081;
    dh_src.setUpServerSocket(port2);

    // Aspetta una connessione da SRC
    dh_src.waitForConnectionFromClient();

    long long int G = dh_src.receiveLongLong();
    if (G == -1) {
        std::cerr << "Errore durante la ricezione della chiave pubblica dal destinatario." << std::endl;
        dh_src.closeSockets();
        return 1;
    }else{
        std::cerr << "ricevuto G: " << G << std::endl;
    }

    dh_src.closeSockets();

    std::cerr << "--------------------------" << std::endl;

    // Calcola la chiave a
    long long int a = dh_src.getPublicKey();
    std::cerr << "la chiave a è: " << a << std::endl;

    std::cerr << "--------------------------" << std::endl;
    
    //calcolo la chiave x con power
    long long int x = dh_src.power(G,a,P);
    std::cerr << "la chiave x: " << x << std::endl;

    std::cerr << "--------------------------" << std::endl;   

    // Configurazione della socket server
    int port3= 9096;
    dh_src.setUpServerSocket(port3);

    // Aspetta una connessione da SRC
    dh_src.waitForConnectionFromClient();
    
    //ricevi y dal destinatario
    long long int y = dh_src.receiveLongLong();
    if (y == -1) {
        std::cerr << "Errore durante la ricezione della chiave pubblica dal destinatario." << std::endl;
        dh_src.closeSockets();
        return 1;
    }else{
        std::cerr << "ricevuto y: " << y << std::endl;
    }

    dh_src.closeSockets();

    std::cerr << "--------------------------" << std::endl;

    sleep(1);

    int port4 = 7076;
    dh_src.setUpClientSocket(port4);
      
    //invia x al destinatario
    int d = dh_src.sendLongLong(x);
    if (d==-1) {
        std::cerr << "Errore durante l'invio della chiave pubblica al destinatario." << std::endl;
        dh_src.closeSocket();
        return 1;
    }else{
        std::cerr << "inviato bene x" << std::endl;

    std::cerr << "--------------------------" << std::endl;

    // Chiudi la connessione
    dh_src.closeSockets();

    std::cerr << "--------------------------" << std::endl;

    //calcola ka, la chiave condivisa tra SRC e DST
    long long int ka = dh_src.power(y, a, P);
    cout << "La chiave condivisa per SRC e DST è : " << ka << endl;

    return ka;
}
}