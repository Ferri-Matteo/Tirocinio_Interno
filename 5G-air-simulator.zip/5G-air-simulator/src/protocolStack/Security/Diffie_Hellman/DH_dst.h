/*
Nome del file:  "DH_dst.h"

Descrizione:    E' il codice con l'instestazione di DH_dst.cpp.
                Viene definita una classe chiamata DH_dst, che ha un costruttore vuoto 
                e un metodo chiamato main_DH_DST.
*/

#include <iostream>
#include <string>
#include <unistd.h>
#include "DH.h"

using namespace std;

class DH_dst{
    public:
    DH_dst(){};
    long long int main_DH_DST();
};