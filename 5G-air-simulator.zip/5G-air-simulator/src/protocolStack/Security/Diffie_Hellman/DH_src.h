/*
Nome del file:  "DH_src.h"

Descrizione:    E' il codice con l'instestazione di DH_src.cpp.
                Viene definita una classe chiamata DH_src, che ha un costruttore vuoto 
                e un metodo chiamato main_DH_src.
*/

#include <iostream>
#include <string>
#include <unistd.h>
#include "DH.h"

using namespace std;

class DH_src{
    public:
    DH_src(){};
    long long int main_DH_src();
};