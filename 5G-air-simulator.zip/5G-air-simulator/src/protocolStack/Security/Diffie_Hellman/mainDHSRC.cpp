/*
Nome del file:  "mainDHSRC.cpp"

Descrizione:    E' il main dell'applicazione Diffie_Hellman per il sorgente
*/

#include "DH_src.h"

int main(){
    
    DH_src ds;
    std::cerr << "inizia il main" << std::endl;
    long long int risultato = ds.main_DH_src();
    std::cerr << "finito il main, risultato: "  << risultato << std::endl;  
    return 0;
}