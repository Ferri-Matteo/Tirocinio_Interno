#include "AES_DST.h"

/*
Nome del file:  "AES_DST.cpp"

Descrizione:    La funzione main_AES_DST inizia creando un oggetto di DH_src chiamato dd e 
                un oggetto di AES chiamato a. Successivamente, viene stampato un messaggio di debug per indicare 
                l'inizio della fase di Diffie-Hellman. Viene chiamata la funzione main_DH_src di dd per 
                ottenere un valore intero. 
                Questo valore intero viene reinterpretato come un puntatore a un array di unsigned char 
                e assegnato a secretKeyDST. Viene stampato un altro messaggio di debug per indicare 
                la fine della fase di Diffie-Hellman. 
                La variabile packetSize viene inizializzata a 16, che rappresenta la lunghezza del pacchetto. 
                Viene stampato un messaggio di debug per assicurarsi che la lunghezza del pacchetto 
                sia multipla di 16 byte. Viene calcolato il paddingSize, che rappresenta il numero di byte 
                di padding necessari per rendere la lunghezza del pacchetto multipla di 16 byte. 
                Viene creato un nuovo array di unsigned char chiamato inDST con dimensione pari a 
                packetSize + paddingSize. I dati originali vengono copiati in inDST e vengono 
                aggiunti byte di padding. Viene calcolata la nuova dimensione del pacchetto. 
                Viene stampato un messaggio di debug per indicare l'inizio della fase di decriptazione. 
                Viene chiamata la funzione DecryptECB di a per decriptare il pacchetto. 
                Viene stampato un messaggio di debug per indicare la fine della fase di decriptazione.
                Viene stampato il contenuto del puntatore decryptedData e infine viene restituito decryptedData.
*/

unsigned char* AES_DST::main_AES_DST(unsigned char* Packet) {
    DH_src dd; // Creo un oggetto di DH_DST   
    AES a(AESKeyLength::AES_128); //creo un oggetto di AES

    std::cerr << "--------------------------" << std::endl;

    std::cerr << "inizio Diffie_Hellman" << std::endl;

    std::cerr << "--------------------------" << std::endl;

    int intValue = dd.main_DH_src();
    const unsigned char* secretKeyDST = reinterpret_cast<const unsigned char*>(&intValue);

    std::cerr << "--------------------------" << std::endl;

    std::cerr << "fine Diffie_Hellman" << std::endl;

    std::cerr << "--------------------------" << std::endl;
   
    unsigned int packetSize = 16; // Lunghezza pacchetto

    std::cerr << "assicurarsi che la lunghezza del pacchetto sia multipla di 16 byte" << std::endl;

    // Assicura che la lunghezza del pacchetto sia multipla di 16 byte
    int paddingSize = 16 - (packetSize % 16);
    unsigned char* inDST = new unsigned char[packetSize + paddingSize];
    memcpy(inDST, &Packet, packetSize); // Copia i dati originali
    memset(inDST + packetSize, 0, paddingSize); // Aggiungi byte di padding
    unsigned int newPacketSize = packetSize + paddingSize;
    
    std::cerr << "packetSize: " << newPacketSize<< std::endl; 

    std::cerr << "--------------------------" << std::endl;

    std::cerr << "inizio a decriptare" << std::endl;
    unsigned char* decryptedData = a.DecryptECB(inDST, newPacketSize, secretKeyDST); // Decripta il pacchetto
    std::cerr << "finito di decriptare" << std::endl;
    
    std::cerr << "--------------------------" << std::endl;

    std::cerr << "Contenuto del puntatore: " << decryptedData << std::endl;
   
    return decryptedData;
}

/*
unsigned char* AES_DST::main_AES_DST(unsigned char* compressedPacket, int packetSize) {
    DH_DST dd; // Creo un oggetto di DH_DST   
    AES a(AESKeyLength::AES_128); //creo un oggetto di AES
    const unsigned char* decompressedData = nullptr;
    decompressedData = new unsigned char[100];

    int intValue = dd.main_DH_DST();
    const unsigned char* secretKeyDST = reinterpret_cast<const unsigned char*>(&intValue);

   //int intValue = dd.main_DH_DST(); 
    //unsigned char byteBuffer[sizeof(int)];
    // Copiare i byte dell'intero nell'array unsigned char
    //memcpy(byteBuffer, &intValue, sizeof(int));
    // assegnare l'array unsigned char a secretKeyDST
    //const unsigned char* secretKeyDST = byteBuffer;
   
    unsigned char* inCompressoDST = compressedPacket; // Pacchetto criptato compresso
    unsigned int inLen = packetSize; // Lunghezza pacchetto
    
    unsigned long tempDest_len = 100;
    unsigned char tempDest[tempDest_len];   
    unsigned long *pDest_len = &tempDest_len;
    
    int intResult = uncompress(tempDest, pDest_len, inCompressoDST, packetSize); // Decomprime i dati
    decompressedData = reinterpret_cast<const unsigned char*>(&intResult);
    unsigned char byteBuffer2[sizeof(int)];
    memcpy(byteBuffer2, &intResult, sizeof(int));
    // assegnare l'array unsigned char a compressedData
    decompressedData = byteBuffer2;

    unsigned char* decryptedData = a.DecryptECB(decompressedData, inLen, secretKeyDST); // Decripta il pacchetto
   
    delete[] decompressedData; // Elimina la memoria allocata per i dati decompressi
   
    return decryptedData;
}
*/

 
