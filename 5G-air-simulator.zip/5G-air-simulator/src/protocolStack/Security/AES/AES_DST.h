#ifndef _AES_DST_H_
#define _AES_DST_H_

/*
AES per il destintario:

Nome del file:   "AES_DST.h"

Descrizione:     La classe AES_DST ha le seguenti variabili membro private:
                 - secretKeyDST: un array costante di unsigned char che rappresenta la chiave segreta utilizzata per la decrittazione.
                 - in: un array costante di unsigned char che rappresenta i dati di input da decrittare e decomprimere.
                 - inLen: un intero non firmato che rappresenta la lunghezza dei dati di input.
                 - v: un array di unsigned char utilizzato come buffer temporaneo.

                Il metodo pubblico main_AES_DST prende due parametri:
                - compressedPacket: un puntatore a un array di unsigned char che rappresenta i dati compressi e criptati.
                - packetSize: un intero che rappresenta la dimensione di compressedPacket.

                La funzione main_AES_DST crea prima un oggetto della classe DH_DST per ottenere la chiave 
                segreta utilizzando il protocollo di scambio di chiavi Diffie-Hellman. Infine, decrittografa
                i dati decompressi utilizzando la funzione DecryptECB della libreria AES.h e restituisce 
                un puntatore ai dati decrittati.

                Questo file di intestazione deve essere incluso in qualsiasi file sorgente che necessita 
                di utilizzare la classe AES_DST.
*/

#include "AES.h"
#include "../Diffie_Hellman/DH_src.h"
#include "../../packet/Packet.h"
#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
//#include "miniz.c"

class AES_DST {
private:
    const unsigned char* secretKeyDST;
    const unsigned char* in;
    unsigned int inLen;
    unsigned char* v;

public:
    unsigned char* main_AES_DST(unsigned char* compressedPacket);
};

#endif
*/

#include "AES.h"
#include "../Diffie_Hellman/DH_src.h"
#include "../../packet/Packet.h"
#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
//#include "miniz.c"

class AES_DST{

    private:
    const unsigned char* secretKeyDST;
    const unsigned char* in;
    unsigned int inLen;
    unsigned char *v;

    public:
    unsigned char* main_AES_DST(unsigned char* compressedPacket);
    

};

#endif
