/*
Nome del file:  "mainAESSRC.cpp"

Descrizione:     E' il codice main dell'applicazione AES per il sorgente
*/

#include "AES_SRC.h"

int main() {
    int p = 555;
    int size = sizeof(p);
    AES_SRC sr;
    const unsigned char* s= sr.main_AES_SRC(p,size) ;
    return 0;
    
}