
/*
Nome del file:  "mainAESDST.cpp"

Descrizione:     E' il codice main dell'applicazione AES da parte del destinatario del pacchetto
*/

#include "AES_DST.h"

int main() {
    unsigned char a = 165; 
    unsigned char* Packet;  // Dichiarazione di un puntatore a unsigned char
    // Assegnazione del puntatore alla variabile 'a' (o a qualsiasi altra variabile)
    Packet = &a;
    AES_DST ad;
    const unsigned char* s= ad.main_AES_DST(Packet) ;
    return 0;
    
}