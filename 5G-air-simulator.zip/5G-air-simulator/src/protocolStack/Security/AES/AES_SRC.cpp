#include "AES_SRC.h"

/*
Nome del file: "AES_SRC.cpp"

Descrizione:    La funzione  main_AES_SRC  esegue la crittografia AES di un pacchetto di 
                dati utilizzando una chiave segreta generata attraverso lo scambio di chiavi Diffie-Hellman. 
                Il pacchetto crittografato viene restituito come un puntatore a un array di caratteri 
                non firmati.
*/

const unsigned char* AES_SRC::main_AES_SRC(int packet, int packetSize){
    
    DH_dst ds; //creo un oggetto di DH_SRC

    std::cerr << "-------------------------" << std::endl;

    std::cerr << "AESKeyLength::AES_128" << std::endl;

    AES a(AESKeyLength::AES_128); //creo un oggetto di AES

    std::cerr << "-------------------------" << std::endl;

    std::cerr << "inizio Diffie_Hellman" << std::endl;

    std::cerr << "-------------------------" << std::endl;

    int intValue = ds.main_DH_DST(); // Assegno a intValue il valore di ritorno di main_DH_SRC, cioè ka

    std::cerr << "-------------------------" << std::endl;

    std::cerr << "finisco Diffie_Hellman" << std::endl;

    std::cerr << "-------------------------" << std::endl;

    // Creare un array di unsigned char per memorizzare i byte dell'intero
    unsigned char byteBuffer[sizeof(int)];
    // Copiare i byte dell'intero nell'array unsigned char
    memcpy(byteBuffer, &intValue, sizeof(int));
    // assegnare l'array unsigned char a secretKeyDST
    const unsigned char* secretKeySRC = byteBuffer;

    unsigned int inLen = packetSize; /*lunghezza pacchetto*/
    std::cerr << "Mi assicuro che il pacchetto abbia lunghezza multipla di 16. ora è lungo: " << inLen << std::endl;
    // Assicura che la lunghezza del pacchetto sia multipla di 16 byte
    int paddingSize = 16 - (inLen % 16);
    unsigned char* in = new unsigned char[inLen + paddingSize];
    memcpy(in, &packet, inLen);
    memset(in + inLen, static_cast<unsigned char>(paddingSize), paddingSize); // Aggiungi padding PKCS7
    unsigned int newInLen = inLen + paddingSize;
    std::cerr << "lunghezza del pacchetto dopo il pudding: " << newInLen << std::endl;   

    std::cerr << "------------------------------" << std::endl;

    std::cerr << "inizio a criptare" << std::endl;
    unsigned char *encryptedData = a.EncryptECB(in, newInLen, secretKeySRC); //cripta con AES il pacchetto
    std::cerr << "finisco di criptare" << std::endl;

    std::cout << "Contenuto del puntatore: " << encryptedData << std::endl;

    std::cerr << "-------------------------" << std::endl;
    
    return encryptedData;
}

/*
const unsigned char* AES_SRC::main_AES_SRC(int packet, int packetSize){
    
    DH_SRC ds; //creo un oggetto di DH_SRC
    AES a(AESKeyLength::AES_128); //creo un oggetto di AES
    
    const unsigned char* compressedData = nullptr;
    compressedData = new unsigned char[100];
   
    int intValue = ds.main_DH_SRC(); // Assegno a intValue il valore di ritorno di main_DH_SRC, cioè ka
    // Creare un array di unsigned char per memorizzare i byte dell'intero
    unsigned char byteBuffer[sizeof(int)];
    // Copiare i byte dell'intero nell'array unsigned char
    memcpy(byteBuffer, &intValue, sizeof(int));
    // assegnare l'array unsigned char a secretKeyDST
    const unsigned char* secretKeySRC = byteBuffer;
    
    int pacchetto = packet; //pacchetto non criptato;
    // Creare un array di unsigned char per memorizzare i byte dell'intero
    unsigned char byteBuffer3[sizeof(int)];
    // Copiare i byte dell'intero nell'array unsigned char
    memcpy(byteBuffer3, &pacchetto, sizeof(int));
    // assegnare l'array unsigned char a in
    const unsigned char* in = byteBuffer3;
    
    unsigned int inLen = packetSize; //lunghezza pacchetto

    unsigned char *encryptedData = a.EncryptECB(in, inLen, secretKeySRC); //cripta con AES il pacchetto

    unsigned char tempDest[100];
    unsigned long tempDest_len = 100;
    unsigned long *pDest_len = &tempDest_len;
    
    int intResult = compress(tempDest, pDest_len, encryptedData, packetSize); // comprime i dati criptati
    unsigned char byteBuffer2[sizeof(int)];
    memcpy(byteBuffer2, &intResult, sizeof(int));
    // assegnare l'array unsigned char a compressedData
    compressedData = byteBuffer2;
    
    delete[] encryptedData; // Elimina la memoria allocata per i dati criptati
    
    return compressedData;
}
*/



