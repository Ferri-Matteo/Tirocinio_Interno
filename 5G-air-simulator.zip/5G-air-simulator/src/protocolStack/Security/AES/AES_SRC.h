#ifndef _AES_SRC_H_
#define _AES_SRC_H_


/*
AES per il sorgente:

Nome del file:   "AES_SRC.h"

Descrizione:     Il codice è un'intestazione per la classe AES_SRC. La classe definisce un oggetto 
                 che implementa l'algoritmo AES per la crittografia e la decrittografia dei dati. 
                 La classe contiene un metodo chiamato main_AES_SRC che prende in input un pacchetto 
                 e la dimensione del pacchetto e restituisce la chiave segreta AES per il pacchetto. 
                 La classe utilizza anche altre librerie come DH_dst.h e Packet.h. 
                 Inoltre, il codice definisce alcuni tipi di dati e dichiara variabili private 
                 utilizzate all'interno della classe.
*/

#include "AES.h"
#include "../Diffie_Hellman/DH_dst.h"
#include "../../packet/Packet.h"
#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
//#include "miniz.c"

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint;

class AES_SRC{
    private:    
    const unsigned char *secretKeySRC;    
    unsigned char *d;    
    const unsigned int *in;
    unsigned int inLen;

    public:
    const unsigned char* main_AES_SRC(int packet, int packetSize);
    AES_SRC(){};

};

#endif
